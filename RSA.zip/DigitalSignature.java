import javax.crypto.Cipher;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class DigitalSignature {

  private PrivateKey privateKey;
  private PublicKey publicKey;

  // Use the same key size as in Task 1
  private static final int KEY_SIZE = 1024;

  public void generateKeyPair() {
    try {
      KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
      keyPairGenerator.initialize(KEY_SIZE);
      KeyPair keyPair = keyPairGenerator.generateKeyPair();
      privateKey = keyPair.getPrivate();
      publicKey = keyPair.getPublic();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public String createDigitalSignature(String message) {
    try {
      // Hash the message
      MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
      byte[] hashedMessage = messageDigest.digest(message.getBytes());

      // Encrypt the hash with the private key to create the digital signature
      Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
      cipher.init(Cipher.ENCRYPT_MODE, privateKey);
      byte[] digitalSignatureBytes = cipher.doFinal(hashedMessage);

      // Return the Base64-encoded digital signature
      return encode(digitalSignatureBytes);
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

  public boolean verifyDigitalSignature(String message, String digitalSignature) {
    try {
      // Hash the message
      MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
      byte[] hashedMessage = messageDigest.digest(message.getBytes());

      // Decode the Base64-encoded digital signature
      byte[] digitalSignatureBytes = decode(digitalSignature);

      // Decrypt the digital signature with the public key
      Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
      cipher.init(Cipher.DECRYPT_MODE, publicKey);
      byte[] decryptedSignature = cipher.doFinal(digitalSignatureBytes);

      // Compare the decrypted signature with the original hash
      return MessageDigest.isEqual(hashedMessage, decryptedSignature);
    } catch (Exception e) {
      e.printStackTrace();
      return false;
    }
  }

  private static String encode(byte[] data) {
    return Base64.getEncoder().encodeToString(data);
  }

  private static byte[] decode(String data) {
    return Base64.getDecoder().decode(data);
  }

  public static void main(String[] args) {
    DigitalSignature digitalSignature = new DigitalSignature();
    digitalSignature.generateKeyPair();

    String originalMessage = "Hello, this is a message for digital signature.";
    String digitalSignature1 = digitalSignature.createDigitalSignature(originalMessage);

    System.out.println("Original Message: " + originalMessage);
    System.out.println("Digital Signature: " + digitalSignature);

    boolean isSignatureValid = digitalSignature.verifyDigitalSignature(originalMessage, digitalSignature1);
    System.out.println("Is Signature Valid? " + isSignatureValid);
  }
}
