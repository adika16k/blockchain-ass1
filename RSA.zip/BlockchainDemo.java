import java.security.NoSuchAlgorithmException;

public class BlockchainDemo {
  public static void main(String[] args) throws NoSuchAlgorithmException {
    // Create a new blockchain
    Blockchain blockchain = new Blockchain();

    // Adding blocks to the blockchain
    blockchain.addBlock(new Block(blockchain.getLastBlock().getPreviousHash()));
    blockchain.addBlock(new Block(blockchain.getLastBlock().getPreviousHash()));
    blockchain.addBlock(new Block(blockchain.getLastBlock().getPreviousHash()));

    // Print the blockchain
    blockchain.printBlockchain();
  }
}
