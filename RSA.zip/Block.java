import java.security.MessageDigest;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;

class Block {
  private String previousHash;
  private List<Transaction> transactions;
  private String merkleRoot;
  private long timestamp;
  private int nonce;

  public Block(String previousHash) {
    this.previousHash = previousHash;
    this.transactions = new ArrayList<>();
    this.timestamp = System.currentTimeMillis();
    this.nonce = 0;
    this.merkleRoot = calculateMerkleRoot();
  }

  public String getPreviousHash() {
    return previousHash;
  }

  public String getMerkleRoot() {
    return merkleRoot;
  }

  public List<Transaction> getTransactions() {
    return transactions;
  }

  public long getTimestamp() {
    return timestamp;
  }

  public int getNonce() {
    return nonce;
  }

  public void addTransaction(Transaction transaction) {
    transactions.add(transaction);
    this.merkleRoot = calculateMerkleRoot();
  }

  private String calculateMerkleRoot() {
    List<String> transactionHashes = new ArrayList<>();

    for (Transaction transaction : transactions) {
      String transactionHash = applySHA256(
        transaction.getSender() + transaction.getRecipient() + transaction.getAmount());
      transactionHashes.add(transactionHash);
    }

    return constructMerkleTree(transactionHashes).get(0);
  }

  private List<String> constructMerkleTree(List<String> transactionHashes) {
    List<String> merkleTree = new ArrayList<>(transactionHashes);

    while (merkleTree.size() > 1) {
      List<String> newTreeLayer = new ArrayList<>();

      for (int i = 0; i < merkleTree.size(); i += 2) {
        String hash1 = merkleTree.get(i);
        String hash2 = (i + 1 < merkleTree.size()) ? merkleTree.get(i + 1) : hash1;

        String combinedHash = applySHA256(hash1 + hash2);
        newTreeLayer.add(combinedHash);
      }

      merkleTree = newTreeLayer;
    }

    return merkleTree;
  }

  private String applySHA256(String input) {
    try {
      MessageDigest digest = MessageDigest.getInstance("SHA-256");
      byte[] hash = digest.digest(input.getBytes("UTF-8"));

      StringBuilder hexString = new StringBuilder();
      for (byte b : hash) {
        String hex = Integer.toHexString(0xff & b);
        if (hex.length() == 1) hexString.append('0');
        hexString.append(hex);
      }

      return hexString.toString();
    } catch (Exception e) {
      throw new RuntimeException(e);
    }

  }
  public boolean verifyTransactionsDigitalSignatures() {
    for (Transaction transaction : transactions) {
      PublicKey publicKey = RSA.getPublicKeyFromPEM(transaction.getSenderPublicKeyPEM());
      if (!transaction.verifyDigitalSignature(publicKey)) {
        return false;
      }
    }
    return true;
  }

}
