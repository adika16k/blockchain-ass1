import java.security.*;
import java.util.Base64;

class Transaction {
  private String sender;
  private String recipient;
  private double amount;
  private String digitalSignature;
  private PublicKey senderPublicKey;

  public Transaction(String sender, String recipient, double amount, PrivateKey privateKey, PublicKey senderPublicKey) {
    this.sender = sender;
    this.recipient = recipient;
    this.amount = amount;
    this.senderPublicKey = senderPublicKey;
    this.digitalSignature = createDigitalSignature(privateKey);
  }

  public String getSender() {
    return sender;
  }

  public String getRecipient() {
    return recipient;
  }

  public double getAmount() {
    return amount;
  }

  public String getDigitalSignature() {
    return digitalSignature;
  }

  public boolean verifyDigitalSignature(PublicKey publicKey) {
    return RSA.verifyDigitalSignature(getDataToSign(), digitalSignature, senderPublicKey);
  }

  private String createDigitalSignature(PrivateKey privateKey) {
    return RSA.createDigitalSignature(getDataToSign(), privateKey);
  }

  private String getDataToSign() {
    return sender + recipient + amount;
  }

  public String getSenderPublicKeyPEM() {
    byte[] publicKeyBytes = senderPublicKey.getEncoded();
    return Base64.getEncoder().encodeToString(publicKeyBytes);
  }
}
