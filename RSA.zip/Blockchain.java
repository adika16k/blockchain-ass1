import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

class Blockchain {
  private List<Block> chain;

  public Blockchain() throws NoSuchAlgorithmException {
    this.chain = new ArrayList<>();
    // Genesis block
    addBlock(new Block("0"));
  }

  public void addBlock(Block block) throws NoSuchAlgorithmException {
    // Add some sample transactions to the block
    KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
    keyPairGenerator.initialize(1024);

    KeyPair senderKeyPair = keyPairGenerator.generateKeyPair();
    KeyPair minerKeyPair = keyPairGenerator.generateKeyPair();
    KeyPair bobKeyPair = keyPairGenerator.generateKeyPair();
    KeyPair daveKeyPair = keyPairGenerator.generateKeyPair();
    KeyPair malloryKeyPair = keyPairGenerator.generateKeyPair();

    block.addTransaction(new Transaction("System", "Miner", 10.0, senderKeyPair.getPrivate(), senderKeyPair.getPublic()));
    block.addTransaction(new Transaction("Alice", "Bob", 5.0, senderKeyPair.getPrivate(), senderKeyPair.getPublic()));
    block.addTransaction(new Transaction("Charlie", "Dave", 8.0, senderKeyPair.getPrivate(), senderKeyPair.getPublic()));
    block.addTransaction(new Transaction("Eve", "Mallory", 15.0, senderKeyPair.getPrivate(), senderKeyPair.getPublic()));


    chain.add(block);
  }

  public Block getLastBlock() {
    return chain.get(chain.size() - 1);
  }

  public void printBlockchain() {
    for (Block block : chain) {
      System.out.println("Previous Hash: " + block.getPreviousHash());
      System.out.println("Merkle Root: " + block.getMerkleRoot());
      System.out.println("Timestamp: " + block.getTimestamp());
      System.out.println("Nonce: " + block.getNonce());
      System.out.println("Transactions: " + block.getTransactions().size());
      System.out.println("--------");
    }
  }
}
